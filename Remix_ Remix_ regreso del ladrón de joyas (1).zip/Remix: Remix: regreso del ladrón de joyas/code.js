var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var Nelson = createSprite(10, 390,20,20);
Nelson.shapeColor="black";
var Diamante = createSprite(380, 20,30,30);
Diamante.shapeColor="lightblue";
var Laser1 = createSprite(200, 100,200,5);
Laser1.shapeColor="red";
Laser1.velocityX=10;
var Laser2 = createSprite(200, 250,200,5);
Laser2.shapeColor="red";
Laser2.velocityX=7;
var Laser3 = createSprite(220, 200,10,10);
Laser3.shapeColor="red";
Laser3.velocityX=-15;
Laser3.velocityY=-5;
var Laser4 = createSprite(180, 200,10,10);
Laser4.shapeColor="red";
Laser4.velocityX=15;
Laser4.velocityY=5;
var gamefase="inicio";
function draw() 
{
   background("gray");
  drawSprites();
  if (gamefase=="inicio"){
    textSize(20);
    stroke("blue");
    text("presiona espacio para iniciar",90,170);
  }
 if (keyDown("space")){
gamefase="juego";
}
if (gamefase=="juego"){
   if (keyDown("right")){
 Nelson.x=Nelson.x+3; 
} 
if (keyDown("left")){
 Nelson.x=Nelson.x-3; 
} 
if (keyDown("up")){
 Nelson.y=Nelson.y-3; 
} 
if (keyDown("down")){
 Nelson.y=Nelson.y+3;
}
if (Laser1.isTouching(Nelson)||Laser2.isTouching(Nelson)||Laser3.isTouching(Nelson)||Laser4.isTouching(Nelson)){
  gamefase="gameOver";
}
if (gamefase=="gameOver"){   
    textSize(20);
    stroke("blue");
  text("ladron ah sido atrapado", 100,200);
   
Laser1.velocityX=0;
Laser2.velocityX=0;
Laser3.velocityX=0;
Laser3.velocityY=0;
Laser4.velocityX=0;
Laser4.velocityY=0;
Nelson.velocityY=0;
Nelson.velocityX=0;
}
if (gamefase=="gameOver"){
    textSize(20);
    stroke("blue");
  text("ladron ah sido atrapado", 100,200);
}
if (Nelson.isTouching(Diamante)){
  gamefase="win";
}
}
if (gamefase=="win"){
  textSize(20);
stroke("blue");
fill("yellow");
text("¡ganaste!", 150, 170);
    Laser1.velocityX=0;
    Laser2.velocityX=0;
    Laser3.velocityX=0;
    Laser4.velocityX=0;
}
  createEdgeSprites();
  Laser1.bounceOff(rightEdge);
  Laser1.bounceOff(leftEdge);
  Laser2.bounceOff(rightEdge);
  Laser2.bounceOff(leftEdge);
  Nelson.bounceOff(rightEdge);
  Nelson.bounceOff(topEdge);
  Nelson.bounceOff(bottomEdge);
  Nelson.bounceOff(leftEdge);
  Nelson.collide(Laser1);
  Nelson.collide(Laser2);
  Nelson.collide(Diamante);
  Laser3.bounceOff(rightEdge);
  Laser3.bounceOff(topEdge);
  Laser3.bounceOff(bottomEdge);
  Laser3.bounceOff(leftEdge);
  Laser4.bounceOff(rightEdge);
  Laser4.bounceOff(topEdge);
  Laser4.bounceOff(bottomEdge);
  Laser4.bounceOff(leftEdge);
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
